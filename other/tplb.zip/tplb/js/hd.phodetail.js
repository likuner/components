

var curindex;
var imgURLsArr = [];
function getImgDetail(imgDetailContainer, swiperBox, deletecbk){
    curindex = appcan.locStorage.getVal('curindex_KEY');
    imgURLsArr = appcan.locStorage.getVal('imgURLsArr').substring(0,appcan.locStorage.getVal('imgURLsArr').length-2).substr(2).split('","');
    for(var j=curindex; j<imgURLsArr.length; j++){
        $(imgDetailContainer).append('<div class="swiper-slide"><img src="'+imgURLsArr[j]+'" width="100%" height="100%"></div>');
    }
    for(var i=0; i<curindex; i++){
        $(imgDetailContainer).append('<div class="swiper-slide"><img src="'+imgURLsArr[i]+'" width="100%" height="100%"></div>');
    }
    
    var swiper = new Swiper(swiperBox,{loop:true});
    
    $("#singleimgson").click(function(){
        if($("#header").css("z-index") == -999){
            $("#header,#imgbtngrp").stop().slideDown(100);
            $("#header,#imgbtngrp").css("z-index", 999);
            $("#header").css("z-index", 999);
        }else{
            $("#header,#imgbtngrp").stop().slideUp(100);
            $("#header").css("z-index", -999);
        }
    });
    
    $("#imgbtngrp>div:lt(2)").click(function(){
        $("#header").css("z-index", -999);
        $("#imgbtngrp").stop().slideUp(100);
    });
    
    $("#imgbtngrp>#btn").click(function(){
        deletecbk(curindex);
    });
    // $("#imgbtngrp>#btn1").click(function(){
        // cancelcbk(curindex);
    // });
}


function backToPrevPage(prevPageName, prevPageURL){
     appcan.button("#nav-left", "btn-act", function(){
        appcan.window.close(1,200);
        appcan.window.open({
            name:prevPageName,
            data:prevPageURL,
            aniId:9,
            // type:4
        }); 
    }); 
}