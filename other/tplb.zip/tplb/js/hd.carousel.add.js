
function showCarousel(imgContainer, imgURLColl){
     $(imgContainer).empty();               
        for(var i=0; i<imgURLColl.length; i++){
            $(imgContainer).append('<div class="item"><img class="lazyOwl" src="'+imgURLColl[i]+'" width="220px" height="220px"></div>');
        }
        $(imgContainer).owlCarousel({
            items : 4,
            lazyLoad : true,
            navigation : true
        });
}

function openImgDetail(pageName, pageURL){
    var imgURLs = [];
    var imgURLsArr = [];
    var len = $(".item").length;
    for(var i=0; i<len; i++){
        imgURLs.push($($(".item>img")[i]).attr("src"));
    }
    
    $(".item img").click(function(){
        appcan.window.open({
            name:pageName,
            data:pageURL,
            aniId:10,
            dataType:0
        });
        appcan.locStorage.setVal('curindex_KEY',$(this).parent().index('div.item'));
        appcan.locStorage.setVal('imgURLsArr', imgURLs);
    });
}
