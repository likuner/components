

;(function($){

	$.fn.longtap = function(options){
		var defaults = {
			time : 1000,
			funCallback : function(){},
		};

		var options = $.extend(defaults, options);

		this.each(function(){
			var _this = $(this);
			var timeout;
	   
			_this.mousedown(function() {  
			    timeout = setTimeout(function() {   
			        options.funCallback();
			    }, options.time);
			}); 
			   
			_this.mouseup(function() {  
			    clearTimeout(timeout); 
			});  
			  
			_this.mouseout(function() {  
			    clearTimeout(timeout);
			}); 

		});

	}

})(jQuery);







/*

$(function(){
	var timeout ;  
	   
	$(".mydiv").mousedown(function() {  
	    timeout = setTimeout(function() {  
	        $(".mydiv").text("in");  
	    }, 1000);  
	});  
	   
	$(".mydiv").mouseup(function() {  
	    clearTimeout(timeout);  
	    // $("#mydiv").text("out");  
	});  
	  
	$("#mydiv").mouseout(function() {  
	    clearTimeout(timeout);  
	    // $("#mydiv").text("out");  
	}); 

});

*/